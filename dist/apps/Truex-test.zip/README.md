# truex-test

## Objective
The app initially loads onto an Episode Detail Screen that takes details from the payload and displays the title, description and cover art, along with a play button to play the video.
Clicking the play button takes the user to the PlayerScreen to play the video from the payload and the player uses **Roku Ad Framework (RAF)** with **TrueX Ad Integration** and gets its data from the payload to be as a standin for server-side ad insertion (SSAI).  
When Video has ended, the user will be prompted with a button to return to the Episode Detail Screen

## To Build
Take the zip file from /dist/apps/ and side load it onto your Roku
